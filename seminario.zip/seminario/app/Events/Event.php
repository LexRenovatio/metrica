<?php namespace seminario\Events;

abstract class Event {

	//

}
