<?php namespace seminario\Commands;

abstract class Command {

	//

}
